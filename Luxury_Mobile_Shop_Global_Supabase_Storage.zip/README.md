# Luxury Mobile Shop — GitHub Pages

Premium black/gold storefront for Luxury Mobile Shop.

### Included
- Locked Admin Dashboard
- Username: `khurshaidshabeer`
- Password: `khurshaidshabeer@12`
- Add product image + video
- Product name, price, stock and full details
- Public product cards with media/details
- WhatsApp “Choose & WhatsApp” ordering
- Help Center and Repair Service
- Contact numbers: 03312084336, 03358722470
- WhatsApp: 03716686383
- Responsive luxury black/gold design

### GitHub Pages
Upload `index.html` to your repository and enable GitHub Pages from the `main` branch.

### Security note
This static version puts the login check in browser JavaScript, so it is **not a secure production authentication system**. Anyone with access to the source can inspect the credentials. For real protection, use server-side authentication/database hosting (for example Supabase/Firebase/backend).

The current product data is stored in the browser's local storage. For multi-device admin/customer synchronization, connect a real database and storage service.


## Supabase Storage button
The Admin area now includes an **Open Supabase Storage** button. It opens the Storage section of this project's Supabase dashboard in a new tab.

The website only contains the Supabase publishable key. Never place the Supabase secret/service key in frontend code.
