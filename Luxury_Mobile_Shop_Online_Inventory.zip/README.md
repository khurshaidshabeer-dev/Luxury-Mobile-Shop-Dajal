# Luxury Mobile Shop — Online Inventory

This version uses Supabase for the shared online product inventory.

## What changed
- Products added from Admin Dashboard are saved in Supabase, not only browser localStorage.
- Visitors on other phones, PCs, browsers, and locations can see the same products.
- Product images/videos are uploaded to Supabase Storage.
- Public inventory refreshes every 15 seconds.
- Admin login uses Supabase Authentication (email + password) when Supabase is configured.

## Setup
1. Open Supabase SQL Editor for your project.
2. Run `supabase_setup.sql`.
3. In Supabase Authentication, create the admin user with the email/password you want to use.
4. Open the website and click Admin.
5. Log in with that Supabase admin email and password.
6. Add products. They will become visible online to everyone.

## Important security note
Only the publishable key belongs in this website's HTML. NEVER put the Supabase secret/service key in frontend HTML, GitHub Pages, JavaScript, or a public repository.

Because a Supabase secret key was shared in chat, rotate/revoke that secret key in your Supabase project before using this website publicly.

## GitHub Pages
Upload `index.html` (and `.nojekyll` if needed) to your GitHub Pages repository. The website will connect directly to Supabase.
